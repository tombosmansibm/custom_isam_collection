import logging
import ibmsecurity.utilities.tools

logger = logging.getLogger(__name__)
requires_model="Appliance"


def get_timezones(isamAppliance, check_mode=False, force=False):
    """
    Retrieving the list of valid timezones
    """
    #return isamAppliance.invoke_get("TBOSMANS Retrieving the list of valid timezones",
    #                                "/time_cfg/I18nTimezone", requires_model=requires_model)
    ret_obj =  isamAppliance.invoke_get("TBOSMANS Retrieving the list of valid timezones",
                                    "/time_cfg/I18nTimezone", requires_model=requires_model)
    ret_obj['warnings'] = "THIS IS CUSTOM CODE"
    ret_obj['data'] =  [{
                                    "id": "Home",
                                    "name": "UTC+00:00 Home"
                                }]
    return ret_obj
